=== Plugin Name ===
Contributors: Kevin Greene
Website: http://www.infinitescripts.com
Donate link: PayPal.Me/InfiniteScripts
Tags: 
Requires at least: 
Tested up to: 
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

#Description

