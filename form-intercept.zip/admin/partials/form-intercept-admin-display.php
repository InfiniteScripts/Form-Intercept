<?php

/**
 * Admin Area
 *
 * @link       http://www.infinitescripts.com/form-intercept
 * @since      1.0.0
 *
 * @package    form_intercept
 * @subpackage form_intercept/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->



